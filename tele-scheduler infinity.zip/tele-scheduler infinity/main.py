import asyncio
import math
import random
from datetime import datetime as dt
from telethon import TelegramClient
from datetime import datetime
import pytz
import json

local = pytz.timezone("Asia/Kolkata")

with open("settings.json", "r") as file:
    settings = json.load(file)

api_id = settings["api_id"]
api_hash = settings["api_hash"]
client = TelegramClient("anon.session", api_id, api_hash)


async def main():
    print("Starting Go Scheduler made with ❤️ by @notxok")
    print("Client Authorized ✅")

    if settings["display_chat_ids"]:
        await display_chat_ids(settings["display_limit"])

    tasks = [set_schedule(task) for task in settings["tasks"]]
    print("Tasks started")
    await asyncio.gather(*tasks)


async def display_chat_ids(limit):
    async for dialog in client.iter_dialogs(limit=limit):
        print(f"Name: {dialog.name} | ChatId: {dialog.id}")


async def set_schedule(task):
    while True:
        time_gap = task["gap"]
        time_gap += random.randint(-3, 3)
        print(
            "Will Set next Schedule for task {} in : {} min".format(
                task["task_name"], math.floor(time_gap)
            )
        )
        await asyncio.sleep(time_gap * 60)
        now = dt.now()
        mm = int(now.strftime("%m"))
        dd = int(now.strftime("%d"))
        hh = int(now.strftime("%H"))
        minute = int(now.strftime("%M"))
        sec = int(now.strftime("%S"))
        year = int(now.strftime("%Y"))

        # minute += random.randint(1, 8)
        sec += 30
        if sec > 59:
            minute += 1
            sec %= 60
        if minute > 59:
            hh += 1
            minute %= 60

        try:
            task_time = local.localize(
                datetime(
                    year=year,
                    month=mm,
                    day=dd,
                    hour=hh,
                    minute=minute,
                    second=sec,
                )
            ).astimezone(pytz.utc)

            await client.send_message(
                task["chat_id"], task["message"], schedule=task_time
            )
            print(
                f"\nScheduled Task [{task['task_name']}] Message is scheduled to send at {hh}:{minute}:{sec} Successfully 🚀"
            )
        except Exception as e:
            print(
                "Failed to send Scheduled Task {} in the group: {} Due to error: {}".format(
                    task["task_name"], task["chat_id"], e
                )
            )


with client:
    client.loop.run_until_complete(main())
